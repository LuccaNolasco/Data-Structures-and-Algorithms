package exceptions;

public class ContainerCheioException extends Exception{
  public ContainerCheioException(){
    super("O container está cheio!");
  }
}
